# -*- coding: utf-8 -*-

# This is my first Project, form calculators to this, no tutorials. Fell free to fork

# Ps: Sorry for this monstrosity

# Ps: Ps: Will try to implement list containing themselfs.



import Generator
import Render

tam = int(input("Tamanho do tabuleiro: "))
dif = int(input("Numero de Minas: "))

mineboard = Generator.GerarMinas(tam,dif)
numboard = Generator.MineCounterBoard(mineboard,tam)
renderboard = Render.DefRenderBoard(tam)

ended = False
Render.Numboard(numboard, renderboard, tam)

def game(mineboard,numboard,tam,dif,renderboard):
	while ended == False:
	    valid = False
	    while valid == False:
			    try:
				    y, x  =  input("faça uma jogada: ").split()
				    y, x = int(y), int(x)
				    valid = True		
			    except:
			    	y, x  =  input("faça uma jogada valida: ").split()
			    	valid = False
	    if mineboard[y][x] == -1:
	        ended == True
	        print("Você Perdeu")
	        return
	    renderboard = Render.updateRenderBoard(numboard, renderboard, x, y,tam)
	    Render.Numboard(numboard, renderboard, tam)
	    
	    
game(mineboard,numboard,tam,dif,renderboard)